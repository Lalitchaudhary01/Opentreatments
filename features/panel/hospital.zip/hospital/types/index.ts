export * from "./hospital";
